<?php
require_once 'koneksi.php';
session_start();

if (isset($_SESSION['id_pengguna'])) {
    header("Location: impor.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_pengguna = $_POST['user_pengguna'];
    $kata_sandi = $_POST['kata_sandi'];
    $sql = "SELECT id_pengguna FROM pengguna WHERE user_pengguna='$user_pengguna' AND kata_sandi='$kata_sandi'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION['id_pengguna'] = $row['id_pengguna'];
        header("Location: index.php");
        exit();
    } else {
        $error = "Nama pengguna atau kata sandi salah.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="login-style.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card mt-5">
                    <div class="card-body">
                        <h3 class="text-center mb-4">Login - Admin Ekpedisi Kinlong</h3>
                        <?php
                        if (isset($error)) {
                            echo '<div class="alert alert-danger" role="alert">' . $error . '</div>';
                        }
                        ?>
                        <form action="" method="post">
                            <div class="mb-3">
                                <label for="user_pengguna" class="form-label">Username</label>
                                <input type="text" class="form-control" id="user_pengguna" name="user_pengguna" required>
                            </div>
                            <div class="mb-3">
                                <label for="kata_sandi" class="form-label">Password</label>
                                <input type="password" class="form-control" id="kata_sandi" name="kata_sandi" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>